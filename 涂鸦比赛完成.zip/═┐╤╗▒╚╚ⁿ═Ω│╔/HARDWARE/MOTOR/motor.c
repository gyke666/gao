#include "motor.h"
#include "delay.h"
#include "led.h"


#define  A1   GPIO_SetBits(GPIOC, GPIO_Pin_3);
#define  A2   GPIO_ResetBits(GPIOC, GPIO_Pin_3);

#define  B1   GPIO_SetBits(GPIOC, GPIO_Pin_4);
#define  B2   GPIO_ResetBits(GPIOC, GPIO_Pin_4);

#define  C1   GPIO_SetBits(GPIOC, GPIO_Pin_5);
#define  C2	 GPIO_ResetBits(GPIOC, GPIO_Pin_5);

#define  D1   GPIO_SetBits(GPIOC, GPIO_Pin_6);
#define  D2   GPIO_ResetBits(GPIOC, GPIO_Pin_6);

void motor_configuration(void)
{
	 GPIO_InitTypeDef  GPIO_InitStructure;
		
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	 //ʹ��PB,PE�˿�ʱ��
		
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6;				 //PC.012 �˿�����
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
	 GPIO_Init(GPIOC, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOC.5
	 GPIO_ResetBits(GPIOC,GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6);						 //PC.012 �����
		
}
void motor_control_F(int n)
{
	A1;
	delay_ms(n);
	A2;
	B1;
	delay_ms(n);
	B2;
	C1;
	delay_ms(n);
	C2;
	D1;
	delay_ms(n);
	D2;
}

void motor_control_Z(int n)
{
	A1;
	delay_ms(n);
	A2;
	D1;
	delay_ms(n);
	D2;
	C1;
	delay_ms(n);
	C2;
	B1;
	delay_ms(n);
	B2;
}
void Motor_Ctrl_Off(void){
	GPIO_ResetBits(GPIOC,GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6);
}





